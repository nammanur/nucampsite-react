export const PROMOTIONS = [
    {
        id: 0,
        name: "Mountain Adventure",
        image: "/assets/images/breadcrumb-trail.jpg",
        featured: true,
        description: "Book a 5-day mountain trek with a seasoned outdoor guide! Fly fishing equipment and lessons provided."
    }
]